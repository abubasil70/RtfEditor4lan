<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('DATA_DIR', __DIR__ . '/data');
define('PUBLISH_DIR', __DIR__ . '/published_docs');
define('NICEEDIT_JS', 'nicedit.js');
define('MAX_FILES_PER_USER', 50);
define('PUBLISH_LIFETIME_DAYS', 60);

function ensure_directories() {
    $dirs = [DATA_DIR, PUBLISH_DIR];
    foreach ($dirs as $dir) {
        if (!file_exists($dir)) {
            if (!mkdir($dir, 0755, true)) {
                die("FATAL ERROR: Failed to create required directory: {$dir}. Please create it manually and ensure it's writable by the web server.");
            }
        } elseif (!is_writable($dir)) {
            die("FATAL ERROR: The directory '{$dir}' is not writable by the web server. Please check permissions.");
        }
    }
     if (!file_exists(NICEEDIT_JS)) {
         die("Error: Cannot find ". NICEEDIT_JS .". Please download it and place it in the same directory as this script.");
    }
}

function sanitize_filename($filename) {
    $filename = trim($filename, ". \t\n\r\0\x0B/");
    $filename = str_replace(['../', '..\\'], '', $filename);
    $filename = preg_replace('/[^\p{L}\p{N}_\-\.]/u', '_', $filename);
    if (isset($filename[0]) && $filename[0] === '.') {
        $filename = '_' . substr($filename, 1);
    }
    if (empty($filename)) return null;
    return $filename;
}

function sanitize_directory_name($dirname) {
    $dirname = trim($dirname);
    $dirname = str_replace(['../', '..\\', '/', '.'], '', $dirname);
    $dirname = preg_replace('/[^a-zA-Z0-9_]/', '', $dirname);
    return empty($dirname) ? null : $dirname;
}

function get_user_data_path() {
    if (!isset($_SESSION['userfolder'])) {
        return null;
    }
    $user_folder = $_SESSION['userfolder'];
    $path = DATA_DIR . '/' . $user_folder;

     if (!is_dir($path)) {
         if (!mkdir($path, 0755)) {
              unset($_SESSION['userfolder']);
              header('Location: index.php?error=' . urlencode("User data directory missing or unwritable. Please log in again."));
              exit;
         }
     }
    return $path;
}

function get_user_file_path($filename_unsafe) {
    $user_path = get_user_data_path();
    if (!$user_path) return null;

    $filename_base = basename($filename_unsafe, '.html');
    $filename_sanitized = sanitize_filename($filename_base);

    if (!$filename_sanitized || pathinfo($filename_unsafe, PATHINFO_EXTENSION) !== 'html') {
        return null;
    }

    $final_filename = $filename_sanitized . '.html';
    $filepath = $user_path . '/' . $final_filename;

    if (strpos(realpath($user_path), realpath(DATA_DIR)) !== 0) {
         error_log("Security Alert: User path validation failed for folder: " . $_SESSION['userfolder']);
         unset($_SESSION['userfolder']);
         header('Location: index.php?error=' . urlencode("Security error. Session terminated."));
         exit;
    }

     if (basename($filepath) !== $final_filename) {
          error_log("Security Alert: Filename mismatch after path construction. User: " . $_SESSION['userfolder'] . ", Input: " . $filename_unsafe);
          return null;
     }

    return $filepath;
}

function cleanup_published_files($days = PUBLISH_LIFETIME_DAYS) {
    $path = PUBLISH_DIR . '/';
    $now = time();
    $lifetime = $days * 24 * 60 * 60;

    if (!is_dir($path) || !$handle = opendir($path)) {
        error_log("Cleanup Error: Could not open publish directory: " . $path);
        return;
    }

    while (false !== ($file = readdir($handle))) {
        $filepath = $path . $file;
        if (is_file($filepath) && pathinfo($file, PATHINFO_EXTENSION) === 'html') {
            if (($now - @filemtime($filepath)) >= $lifetime) {
                @unlink($filepath);
            }
        }
    }
    closedir($handle);
}

function publish_document($filename_unsafe) {
    cleanup_published_files();

    $filepath = get_user_file_path($filename_unsafe);
    if (!$filepath || !file_exists($filepath) || !is_readable($filepath)) {
         header('Location: index.php?action=list&error=' . urlencode("Document not found or could not be read for publishing."));
         exit;
    }

    $file_content = file_get_contents($filepath);

    $published_hash = md5($_SESSION['userfolder'] . '/' . basename($filepath));
    $published_filename = $published_hash . '.html';
    $publish_path = PUBLISH_DIR . '/' . $published_filename;

    $published_content = '<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>منشور</title>
    <style>
        body { direction: rtl; max-width: 800px; margin: 20px auto; padding: 20px; font-family: sans-serif; background-color:#fff; border: 1px solid #ccc; }
    </style>
</head>
<body>' .
    $file_content .
'</body>
</html>';

    if (file_put_contents($publish_path, $published_content) !== false) {
        $publish_url = 'published_docs/' . $published_filename;
        header("Location: $publish_url");
        exit();
    } else {
        header('Location: index.php?action=list&error=' . urlencode("Failed to write published file. Check permissions on 'published_docs'."));
        exit;
    }
}

ensure_directories();

$action = $_GET['action'] ?? (isset($_SESSION['userfolder']) ? 'list' : 'login');
$file_param = $_GET['file'] ?? null;
$error = $_GET['error'] ?? null;
$success = $_GET['success'] ?? null;
$user_path = get_user_data_path();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'login') {
    $folder_raw = $_POST['userfolder'] ?? '';
    $folder_sanitized = sanitize_directory_name($folder_raw);

    if ($folder_sanitized) {
        $_SESSION['userfolder'] = $folder_sanitized;
        if (get_user_data_path()) {
            header("Location: index.php?action=list");
            exit;
        } else {
            exit;
        }
    } else {
        $error = "Invalid folder name. Use only letters, numbers, and underscores.";
        $action = 'login';
    }
}

if ($action === 'logout') {
    session_unset();
    session_destroy();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
    }
    header("Location: index.php?action=login&success=" . urlencode("Logged out successfully."));
    exit;
}

if (!isset($_SESSION['userfolder']) && !in_array($action, ['login'])) {
    header("Location: index.php?action=login");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'save') {
    $content = $_POST['content'] ?? '';
    $doc_name_raw = $_POST['doc_name'] ?? '';
    $original_filename_unsafe = $_POST['original_filename'] ?? null;

    $doc_name_sanitized = sanitize_filename($doc_name_raw);

    if (!$doc_name_sanitized) {
        $redirect_url = 'index.php?action=edit';
        if ($original_filename_unsafe) {
             $original_path_info = get_user_file_path($original_filename_unsafe);
             if ($original_path_info) {
                  $redirect_url .= '&file=' . urlencode(basename($original_path_info));
             }
        }
        header('Location: ' . $redirect_url . '&error=' . urlencode("Invalid document name provided."));
        exit;
    }

    $new_filename = $doc_name_sanitized . '.html';
    $new_filepath = $user_path . '/' . $new_filename;

     if (strpos($new_filepath, $user_path . '/') !== 0) {
          header('Location: index.php?action=list&error=' . urlencode("Security Error: Invalid save path detected."));
          exit;
     }

    if ($original_filename_unsafe && basename($original_filename_unsafe) !== $new_filename) {
        $original_filepath = get_user_file_path($original_filename_unsafe);
        if ($original_filepath && file_exists($original_filepath)) {
             if (strpos(realpath($original_filepath), realpath($user_path)) === 0) {
                  unlink($original_filepath);
             } else {
                  error_log("Security Alert: Attempted rename deletion outside user dir. User: " . $_SESSION['userfolder'] . ", File: " . $original_filename_unsafe);
                  header('Location: index.php?action=list&error=' . urlencode("Security error during rename. Original file not deleted."));
                  exit;
             }
        }
    }

    if (file_put_contents($new_filepath, $content) !== false) {
        header('Location: index.php?action=list&success=' . urlencode("Document '$doc_name_sanitized' saved successfully."));
        exit;
    } else {
        $error_msg = "Error saving document '$doc_name_sanitized'. Check server logs or permissions.";
        header('Location: index.php?action=edit&file=' . urlencode($new_filename) . '&error=' . urlencode($error_msg));
        exit;
    }
}

if ($action === 'delete' && $file_param) {
    $filepath = get_user_file_path($file_param);

    if ($filepath && file_exists($filepath) && is_file($filepath)) {
         if (strpos(realpath($filepath), realpath($user_path)) === 0) {
             if (unlink($filepath)) {
                 header('Location: index.php?action=list&success=' . urlencode("Document '" . basename($filepath, '.html') . "' deleted."));
                 exit;
             } else {
                 $error = "Error deleting document '" . basename($filepath, '.html') . "'.";
             }
         } else {
             error_log("Security Alert: Attempted delete outside user dir. User: " . $_SESSION['userfolder'] . ", File: " . $file_param);
             $error = "Security Error: Invalid file path for deletion.";
         }
    } else {
        $error = "Document not found or invalid file specified for deletion.";
    }
    header('Location: index.php?action=list&error=' . urlencode($error));
    exit;
}

if ($action === 'publish' && $file_param) {
    publish_document($file_param);
}

?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مسودة اونلاين المحسنة</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; padding: 0; margin: 0; background-color: #e9ebee; direction: rtl; }
        .container { max-width: 1000px; margin: 20px auto; background: #fff; padding: 0; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); display: flex; min-height: calc(100vh - 40px); }
        .sidebar { width: 250px; background-color: #f0f2f5; padding: 15px; border-left: 1px solid #ddd; display: flex; flex-direction: column; }
        .main-content { flex: 1; padding: 20px; }
        h1, h2 { color: #333; margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 10px; }
        h1 { font-size: 1.8em; }
        h2 { font-size: 1.4em; margin-bottom: 15px;}
        .user-info { margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #ddd; font-size: 0.9em; color: #555; }
        .user-info strong { color: #000; }
        .file-list { list-style: none; padding: 0; margin: 0 0 15px 0; max-height: calc(100vh - 250px); overflow-y: auto;}
        .file-item { background: #fff; margin-bottom: 8px; padding: 8px 12px; border-radius: 4px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #ddd; font-size: 0.95em; }
        .file-item:hover { background-color: #f9f9f9; }
        .file-item a { text-decoration: none; color: #0056b3; font-weight: 500; flex-grow: 1; margin-right: 10px; }
        .file-item a:hover { text-decoration: underline; }
        .file-actions { display: flex; align-items: center; flex-shrink: 0;}
        .file-actions a { margin-left: 8px; display: inline-block; vertical-align: middle;}
        .file-actions img { width: 16px; height: 16px; opacity: 0.7; }
        .file-actions a:hover img { opacity: 1; }
        .button, input[type="submit"] { display: inline-block; background: #007bff; color: white; padding: 10px 15px; border: none; border-radius: 4px; text-decoration: none; cursor: pointer; margin-top: 10px; font-size: 1em; }
        .button:hover, input[type="submit"]:hover { background: #0056b3; }
        .button-new { width: 100%; text-align: center; margin-bottom: 15px; }
        .button-logout { width: 100%; text-align: center; background-color: #6c757d; margin-top: auto; }
         .button-logout img { width: 16px; height: 16px; vertical-align: middle; margin-left: 5px; filter: brightness(0) invert(1); }
        .message { padding: 12px; margin-bottom: 20px; border-radius: 4px; border: 1px solid transparent; }
        .message.error { background-color: #f8d7da; color: #721c24; border-color: #f5c6cb; }
        .message.success { background-color: #d4edda; color: #155724; border-color: #c3e6cb; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; }
        input[type="text"], textarea { width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 1em; }
        textarea { min-height: 450px; }
        .form-group { margin-bottom: 15px; }
        .login-box { max-width: 400px; margin: 60px auto; padding: 30px; background: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
        .login-box h1 { margin-bottom: 20px; }
        .sidebar { border-left: 0; border-right: 1px solid #ddd;}
        .file-item a { margin-right: 0; margin-left: 10px; }
        .file-actions a { margin-left: 0; margin-right: 8px;}
        .button-logout img { margin-left: 0; margin-right: 5px; }
    </style>
    <?php if (in_array($action, ['edit', 'new'])): ?>
        <script src="<?php echo NICEEDIT_JS; ?>"></script>
        <script type="text/javascript">
            bkLib.onDomLoaded(function() {
                new nicEditor({fullPanel : true, iconsPath : '<?php echo str_replace(" ","%20",dirname($_SERVER['PHP_SELF'])); ?>/nicEditorIcons.gif'}).panelInstance('editorArea');
            });
        </script>
    <?php endif; ?>
</head>
<body>

    <?php if ($action === 'login'): ?>
        <div class="login-box">
            <h1>تسجيل الدخول / إنشاء مجلد</h1>
            <?php if ($error): ?><div class="message error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
            <?php if ($success): ?><div class="message success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
            <form action="?action=login" method="POST">
                <div class="form-group">
                    <label for="userfolder">اسم المجلد (انجليزي، ارقام، _ فقط):</label>
                    <input type="text" id="userfolder" name="userfolder"
                           pattern="[A-Za-z0-9_]{3,}" title="Minimum 3 characters: letters, numbers, underscore"
                           required autocomplete="off" placeholder="مثال: my_docs" autofocus>
                </div>
                <button type="submit" class="button">فتح / إنشاء</button>
            </form>
             <p style="margin-top: 15px; font-size: 0.85em; color: #666;">سيتم إنشاء مجلد بهذا الاسم لتخزين مستنداتك.</p>
        </div>

    <?php elseif (isset($_SESSION['userfolder'])): ?>

        <div class="container">
            <aside class="sidebar">
                <div class="user-info">
                    المجلد الحالي: <strong><?php echo htmlspecialchars($_SESSION['userfolder']); ?></strong>
                </div>

                <a href="?action=new" class="button button-new">إنشاء مستند جديد</a>

                <h2>المستندات</h2>
                <ul class="file-list">
                    <?php
                    $files = [];
                    if ($user_path && is_dir($user_path)) {
                         $scan = scandir($user_path);
                         foreach ($scan as $doc) {
                              $filepath = $user_path . '/' . $doc;
                              if ($doc !== '.' && $doc !== '..' && is_file($filepath) && pathinfo($doc, PATHINFO_EXTENSION) === 'html') {
                                   $files[] = $doc;
                              }
                         }
                    }

                    if (empty($files)) {
                        echo "<li style='text-align:center; color:#777;'>لا توجد مستندات.</li>";
                    } else {
                        natsort($files);
                        foreach ($files as $doc) {
                            $doc_name_base = basename($doc, '.html');
                            $doc_name_display = htmlspecialchars(str_replace('_', ' ', $doc_name_base));
                            echo '<li class="file-item">';
                            echo '<a href="?action=edit&file=' . urlencode($doc) . '">' . $doc_name_display . '</a>';
                            echo '<div class="file-actions">';
                            echo '<a href="?action=publish&file=' . urlencode($doc) . '" target="_blank" title="نشر / مشاركة (رابط مؤقت)">';
                            echo '<img src="images/share.png" alt="Publish">';
                            echo '</a>';
                            echo '<a href="?action=delete&file=' . urlencode($doc) . '" onclick="return confirm(\'هل أنت متأكد من حذف المستند: ' . addslashes($doc_name_display) . '؟\');" title="حذف">';
                            echo '<img src="images/delete.png" alt="Delete">';
                            echo '</a>';
                            echo '</div>';
                            echo '</li>';
                        }
                    }
                    ?>
                </ul>
                 <a href="?action=logout" class="button button-logout">
                     <img src="images/qt.png" alt="">
                     تسجيل الخروج
                 </a>
            </aside>

            <main class="main-content">
                <?php if ($error): ?><div class="message error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
                <?php if ($success && $action === 'list'): ?>
                    <div class="message success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>

                <?php
                if ($action === 'new' || $action === 'edit'):
                    $doc_content = '';
                    $doc_name = '';
                    $original_filename_for_form = '';
                    $is_editing = ($action === 'edit' && $file_param);

                     if ($action === 'new' && count($files) >= MAX_FILES_PER_USER) {
                          echo "<h2>حد الملفات</h2>";
                          echo "<div class='message error'>عذرًا، لقد وصلت إلى الحد الأقصى لعدد الملفات (" . MAX_FILES_PER_USER . "). لا يمكنك إنشاء مستند جديد حتى تقوم بحذف بعض المستندات القديمة.</div>";
                     }
                     else {
                         if ($is_editing) {
                             $filepath = get_user_file_path($file_param);

                             if ($filepath && file_exists($filepath) && is_readable($filepath)) {
                                 if (strpos(realpath($filepath), realpath($user_path)) === 0) {
                                     $doc_content = file_get_contents($filepath);
                                     $doc_name = basename($filepath, '.html');
                                     $original_filename_for_form = basename($filepath);
                                     echo "<h2>تحرير: " . htmlspecialchars(str_replace('_', ' ', $doc_name)) . "</h2>";
                                 } else {
                                     echo "<div class='message error'>خطأ أمني: مسار الملف غير صالح.</div>";
                                     $action = 'error';
                                 }
                             } else {
                                 echo "<div class='message error'>خطأ: المستند غير موجود أو غير قابل للقراءة. <a href='index.php'>العودة للقائمة</a></div>";
                                 $action = 'error';
                             }
                         } else {
                             echo "<h2>إنشاء مستند جديد</h2>";
                         }

                         if ($action !== 'error') :
                         ?>
                         <form action="?action=save" method="POST">
                             <input type="hidden" name="original_filename" value="<?php echo htmlspecialchars($original_filename_for_form); ?>">

                             <div class="form-group">
                                 <label for="doc_name">اسم المستند:</label>
                                 <input type="text" id="doc_name" name="doc_name" value="<?php echo htmlspecialchars($doc_name); ?>" required placeholder="اسم المستند (يفضل بدون رموز خاصة)" maxlength="60" <?php if ($action === 'new') echo 'autofocus'; ?>>
                                 <small>يمكن استخدام الحروف والأرقام والشرطة السفلية (-). سيتم تحويل المسافات إلى شرطة سفلية. تغيير الاسم هنا سيؤدي إلى إعادة تسمية الملف.</small>
                             </div>

                             <div class="form-group">
                                 <label for="editorArea">المحتوى:</label>
                                 <textarea id="editorArea" name="content" style="width: 100%; height: 450px;"><?php echo htmlspecialchars($doc_content); ?></textarea>
                             </div>

                             <button type="submit" class="button">حفظ المستند</button>
                             <a href="index.php?action=list" class="button" style="background-color: #6c757d; margin-right: 10px;">إلغاء / عودة للقائمة</a>
                         </form>
                         <?php
                         endif;
                     }

                elseif ($action === 'list'):
                     echo "<h2>لوحة التحكم</h2>";
                     echo "<p>مرحباً بك في محرر المستندات البسيط. اختر مستندًا من القائمة على اليمين للتحرير، أو انقر فوق 'إنشاء مستند جديد'.</p>";
                     echo "<p>عدد المستندات الحالية: " . count($files) . " / " . MAX_FILES_PER_USER . "</p>";
                else:
                     echo "<h2>خطأ</h2><div class='message error'>الإجراء المطلوب غير معروف.</div>";
                endif;
                ?>
            </main>
        </div>

    <?php endif; ?>

</body>
</html>