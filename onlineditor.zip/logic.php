<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1); // Development only

// --- Configuration ---
define('DATA_DIR', __DIR__ . '/data');
define('PUBLISH_DIR', __DIR__ . '/published_docs');
define('NICEEDIT_JS', 'nicedit.js'); // Relative path for index.php to use
define('MAX_FILES_PER_USER', 50);
define('PUBLISH_LIFETIME_DAYS', 60);

// --- Function Definitions ---

function ensure_directories() {
    $dirs = [DATA_DIR, PUBLISH_DIR];
    foreach ($dirs as $dir) {
        if (!file_exists($dir)) {
            if (!mkdir($dir, 0755, true)) {
                die("FATAL ERROR: Failed to create required directory: {$dir}. Please create it manually and ensure it's writable by the web server.");
            }
        } elseif (!is_writable($dir)) {
            die("FATAL ERROR: The directory '{$dir}' is not writable by the web server. Please check permissions.");
        }
    }
     // Check for NiceEdit JS relative to index.php's perspective
     if (!file_exists(__DIR__ . '/' . NICEEDIT_JS)) {
         die("Error: Cannot find ". NICEEDIT_JS .". Please download it and place it in the same directory as logic.php and index.php.");
    }
}

function sanitize_filename($filename) {
    $filename = trim($filename, ". \t\n\r\0\x0B/");
    $filename = str_replace(['../', '..\\'], '', $filename);
    $filename = preg_replace('/[^\p{L}\p{N}_\-\.]/u', '_', $filename);
    if (isset($filename[0]) && $filename[0] === '.') {
        $filename = '_' . substr($filename, 1);
    }
    if (empty($filename)) return null;
    return $filename;
}

function sanitize_directory_name($dirname) {
    $dirname = trim($dirname);
    $dirname = str_replace(['../', '..\\', '/', '.'], '', $dirname);
    $dirname = preg_replace('/[^a-zA-Z0-9_]/', '', $dirname);
    return empty($dirname) ? null : $dirname;
}

function get_user_data_path() {
    if (!isset($_SESSION['userfolder'])) {
        return null;
    }
    $user_folder = $_SESSION['userfolder'];
    $path = DATA_DIR . '/' . $user_folder;

     if (!is_dir($path)) {
         if (!mkdir($path, 0755)) {
              unset($_SESSION['userfolder']);
              header('Location: index.php?error=' . urlencode("User data directory missing or unwritable. Please log in again."));
              exit;
         }
     }
    return $path;
}

function get_user_file_path($filename_unsafe) {
    $user_path = get_user_data_path();
    if (!$user_path) return null;

    $filename_base = basename($filename_unsafe, '.html');
    $filename_sanitized = sanitize_filename($filename_base);

    if (!$filename_sanitized || pathinfo($filename_unsafe, PATHINFO_EXTENSION) !== 'html') {
        return null;
    }

    $final_filename = $filename_sanitized . '.html';
    $filepath = $user_path . '/' . $final_filename;

    if (strpos(realpath($user_path), realpath(DATA_DIR)) !== 0) {
         error_log("Security Alert: User path validation failed for folder: " . $_SESSION['userfolder']);
         unset($_SESSION['userfolder']);
         header('Location: index.php?error=' . urlencode("Security error. Session terminated."));
         exit;
    }

     if (basename($filepath) !== $final_filename) {
          error_log("Security Alert: Filename mismatch after path construction. User: " . $_SESSION['userfolder'] . ", Input: " . $filename_unsafe);
          return null;
     }

    return $filepath;
}

function cleanup_published_files($days = PUBLISH_LIFETIME_DAYS) {
    $path = PUBLISH_DIR . '/';
    $now = time();
    $lifetime = $days * 24 * 60 * 60;

    if (!is_dir($path) || !$handle = opendir($path)) {
        error_log("Cleanup Error: Could not open publish directory: " . $path);
        return;
    }

    while (false !== ($file = readdir($handle))) {
        $filepath = $path . $file;
        if (is_file($filepath) && pathinfo($file, PATHINFO_EXTENSION) === 'html') {
            if (($now - @filemtime($filepath)) >= $lifetime) {
                @unlink($filepath);
            }
        }
    }
    closedir($handle);
}

function publish_document($filename_unsafe) {
    cleanup_published_files();

    $filepath = get_user_file_path($filename_unsafe);
    if (!$filepath || !file_exists($filepath) || !is_readable($filepath)) {
         header('Location: index.php?action=list&error=' . urlencode("Document not found or could not be read for publishing."));
         exit;
    }

    $file_content = file_get_contents($filepath);

    $published_hash = md5($_SESSION['userfolder'] . '/' . basename($filepath));
    $published_filename = $published_hash . '.html';
    $publish_path = PUBLISH_DIR . '/' . $published_filename;

    $published_content = '<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>منشور</title>
    <style>
        body { direction: rtl; max-width: 800px; margin: 20px auto; padding: 20px; font-family: sans-serif; background-color:#fff; border: 1px solid #ccc; }
    </style>
</head>
<body>' .
    $file_content .
'</body>
</html>';

    if (file_put_contents($publish_path, $published_content) !== false) {
        $publish_url = 'published_docs/' . $published_filename;
        header("Location: $publish_url");
        exit();
    } else {
        header('Location: index.php?action=list&error=' . urlencode("Failed to write published file. Check permissions on 'published_docs'."));
        exit;
    }
}

// --- Initial Setup ---
ensure_directories();

// --- Global Variables & State ---
$action = $_GET['action'] ?? (isset($_SESSION['userfolder']) ? 'list' : 'login');
$file_param = $_GET['file'] ?? null;
$error = $_GET['error'] ?? null;
$success = $_GET['success'] ?? null;
$user_path = get_user_data_path(); // Might be null if not logged in

$doc_content = '';
$doc_name = '';
$original_filename_for_form = '';
$files = []; // Initialize file list

// --- Action Processing (Handles redirects, must run before HTML output) ---

// Login POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'login') {
    $folder_raw = $_POST['userfolder'] ?? '';
    $folder_sanitized = sanitize_directory_name($folder_raw);

    if ($folder_sanitized) {
        $_SESSION['userfolder'] = $folder_sanitized;
        if (get_user_data_path()) { // This also ensures the directory exists
            header("Location: index.php?action=list");
            exit;
        } else {
            // Error handled by get_user_data_path redirect
            exit;
        }
    } else {
        $error = "Invalid folder name. Use only letters, numbers, and underscores.";
        $action = 'login'; // Force view back to login
    }
}

// Logout GET
if ($action === 'logout') {
    session_unset();
    session_destroy();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
    }
    header("Location: index.php?action=login&success=" . urlencode("Logged out successfully."));
    exit;
}

// --- Actions requiring login ---
if (!isset($_SESSION['userfolder']) && !in_array($action, ['login'])) {
    header("Location: index.php?action=login"); // Redirect if not logged in and not on login action
    exit;
}

// Save POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'save') {
    $content = $_POST['content'] ?? '';
    $doc_name_raw = $_POST['doc_name'] ?? '';
    $original_filename_unsafe = $_POST['original_filename'] ?? null;
    $doc_name_sanitized = sanitize_filename($doc_name_raw);

    if (!$doc_name_sanitized) {
        $redirect_url = 'index.php?action=edit';
        if ($original_filename_unsafe) {
             $original_path_info = get_user_file_path($original_filename_unsafe);
             if ($original_path_info) { $redirect_url .= '&file=' . urlencode(basename($original_path_info)); }
        }
        header('Location: ' . $redirect_url . '&error=' . urlencode("Invalid document name provided."));
        exit;
    }

    $new_filename = $doc_name_sanitized . '.html';
    $new_filepath = $user_path . '/' . $new_filename;

     if (strpos($new_filepath, $user_path . '/') !== 0) {
          header('Location: index.php?action=list&error=' . urlencode("Security Error: Invalid save path detected."));
          exit;
     }

    if ($original_filename_unsafe && basename($original_filename_unsafe) !== $new_filename) {
        $original_filepath = get_user_file_path($original_filename_unsafe);
        if ($original_filepath && file_exists($original_filepath)) {
             if (strpos(realpath($original_filepath), realpath($user_path)) === 0) {
                  unlink($original_filepath);
             } else {
                  error_log("Security Alert: Attempted rename deletion outside user dir. User: " . $_SESSION['userfolder'] . ", File: " . $original_filename_unsafe);
                  header('Location: index.php?action=list&error=' . urlencode("Security error during rename. Original file not deleted."));
                  exit;
             }
        }
    }

    if (file_put_contents($new_filepath, $content) !== false) {
        header('Location: index.php?action=list&success=' . urlencode("Document '$doc_name_sanitized' saved successfully."));
        exit;
    } else {
        $error_msg = "Error saving document '$doc_name_sanitized'. Check server logs or permissions.";
        header('Location: index.php?action=edit&file=' . urlencode($new_filename) . '&error=' . urlencode($error_msg));
        exit;
    }
}

// Delete GET
if ($action === 'delete' && $file_param) {
    $filepath = get_user_file_path($file_param);
    $error_msg = ''; // Use a local var for error message

    if ($filepath && file_exists($filepath) && is_file($filepath)) {
         if (strpos(realpath($filepath), realpath($user_path)) === 0) {
             if (!unlink($filepath)) {
                 $error_msg = "Error deleting document '" . basename($filepath, '.html') . "'.";
             }
         } else {
             error_log("Security Alert: Attempted delete outside user dir. User: " . $_SESSION['userfolder'] . ", File: " . $file_param);
             $error_msg = "Security Error: Invalid file path for deletion.";
         }
    } else {
        $error_msg = "Document not found or invalid file specified for deletion.";
    }

    if ($error_msg) {
        header('Location: index.php?action=list&error=' . urlencode($error_msg));
    } else {
        header('Location: index.php?action=list&success=' . urlencode("Document '" . sanitize_filename(basename($file_param, '.html')) . "' deleted."));
    }
    exit;
}

// Publish GET
if ($action === 'publish' && $file_param) {
    // This function handles its own validation and redirects/exits
    publish_document($file_param);
}

// --- Data Preparation for View (Run after actions) ---

// Populate file list if user is logged in and viewing relevant pages
if ($user_path && in_array($action, ['list', 'edit', 'new'])) {
    if (is_dir($user_path)) {
         $scan = scandir($user_path);
         foreach ($scan as $doc) {
              $filepath = $user_path . '/' . $doc;
              if ($doc !== '.' && $doc !== '..' && is_file($filepath) && pathinfo($doc, PATHINFO_EXTENSION) === 'html') {
                   $files[] = $doc;
              }
         }
         natsort($files); // Sort alphabetically
    } else {
        // Should have been caught earlier, but set an error just in case
        $error = $error ?? "User data directory is missing.";
        $action = 'login'; // Force back to login if directory is unusable
    }
}

// Populate editor fields if editing
if ($action === 'edit' && $file_param) {
    $filepath = get_user_file_path($file_param);

    if ($filepath && file_exists($filepath) && is_readable($filepath)) {
        // Check realpath again before reading
        if (strpos(realpath($filepath), realpath($user_path)) === 0) {
            $doc_content = file_get_contents($filepath);
            $doc_name = basename($filepath, '.html');
            $original_filename_for_form = basename($filepath);
        } else {
            $error = $error ?? "Security Error: Invalid file path.";
            $action = 'list'; // Revert action to list on error
        }
    } else {
        $error = $error ?? "Error: Document not found or unreadable.";
        $action = 'list'; // Revert action to list on error
    }
}

// Check file limit if trying to create new
if ($action === 'new' && count($files) >= MAX_FILES_PER_USER) {
    $error = $error ?? "Sorry, you have reached the maximum file limit (" . MAX_FILES_PER_USER . "). You cannot create a new document until you delete some old ones.";
    $action = 'list'; // Revert action to list view if limit reached
}

// --- End of logic.php ---
// Now index.php will be included/run, and it can use the variables $action, $error, $success, $files, $doc_name, $doc_content etc.