<?php require 'logic.php'; ?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style.css" rel="stylesheet" title="Style" />
    <title>مسودة اونلاين المحسنة</title>
    <style>
       
    </style>
    <?php if (in_array($action, ['edit', 'new'])): ?>
        <script src="<?php echo NICEEDIT_JS; ?>"></script>
        <script type="text/javascript">
            bkLib.onDomLoaded(function() {
                var scriptDir = '<?php echo str_replace(" ","%20",rtrim(dirname($_SERVER['PHP_SELF']), '/\\')); ?>';
                var iconsPath = scriptDir ? scriptDir + '/nicEditorIcons.gif' : 'nicEditorIcons.gif';
                new nicEditor({fullPanel : true, iconsPath : iconsPath}).panelInstance('editorArea');
            });
        </script>
    <?php endif; ?>
</head>
<body>

    <?php if ($action === 'login'): ?>
        <div class="login-box">
            <h1>تسجيل الدخول / إنشاء مجلد</h1>
            <?php if ($error): ?><div class="message error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
            <?php if ($success): ?><div class="message success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
            <form action="index.php?action=login" method="POST">
                <div class="form-group">
                    <label for="userfolder">اسم المجلد (انجليزي، ارقام، _ فقط):</label>
                    <input type="text" id="userfolder" name="userfolder"
                           pattern="[A-Za-z0-9_]{3,}" title="Minimum 3 characters: letters, numbers, underscore"
                           required autocomplete="off" placeholder="مثال: my_project_files" autofocus>
                </div>
                <button type="submit" class="button">فتح / إنشاء</button>
            </form>
             <p>سيتم إنشاء مجلد بهذا الاسم لتخزين مستنداتك إذا لم يكن موجوداً.</p>
        </div>

    <?php elseif (isset($_SESSION['userfolder'])): ?>

        <div class="container">
            <aside class="sidebar">
                <div class="user-info">
                    المجلد الحالي:<br><strong><?php echo htmlspecialchars($_SESSION['userfolder']); ?></strong>
                </div>

                <a href="index.php?action=new" class="button button-new">إنشاء مستند جديد</a>

                <h2>المستندات</h2>
                <ul class="file-list">
                    <?php
                    if (empty($files)) {
                        echo "<li style='text-align:center; color:#7f8c8d; padding: 10px;'>لا توجد مستندات.</li>";
                    } else {
                        foreach ($files as $doc) {
                            $doc_name_base = basename($doc, '.html');
                            $doc_name_display = htmlspecialchars(str_replace('_', ' ', $doc_name_base));
                            $is_active = ($action === 'edit' && $file_param === $doc); // Check if current file is active
                            echo '<li class="file-item' . ($is_active ? ' active' : '') . '">'; // Add active class
                            echo '<a href="index.php?action=edit&file=' . urlencode($doc) . '" class="file-link">' . $doc_name_display . '</a>';
                            echo '<div class="file-actions">';
                            echo '<a href="index.php?action=publish&file=' . urlencode($doc) . '" target="_blank" title="نشر / مشاركة (رابط مؤقت)">';
                            echo '<img src="images/share.png" alt="Publish">';
                            echo '</a>';
                            echo '<a href="index.php?action=delete&file=' . urlencode($doc) . '" onclick="return confirm(\'هل أنت متأكد من حذف المستند: ' . addslashes($doc_name_display) . '؟\');" title="حذف">';
                            echo '<img src="images/delete.png" alt="Delete">';
                            echo '</a>';
                            echo '</div>';
                            echo '</li>';
                        }
                    }
                    ?>
                </ul>
                 <a href="index.php?action=logout" class="button button-logout">
                     <img src="images/qt.png" alt="">
                     تسجيل الخروج
                 </a>
            </aside>

            <main class="main-content">
                <?php if ($error): ?>
                    <div class="message error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <?php if ($success && $action === 'list'): ?>
                    <div class="message success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>

                <?php
                if ($action === 'new' || $action === 'edit'):
                    if ($action === 'edit') {
                         echo "<h2>تحرير: " . htmlspecialchars(str_replace('_', ' ', $doc_name)) . "</h2>";
                    } else {
                         echo "<h2>إنشاء مستند جديد</h2>";
                    }
                ?>
                    <form action="index.php?action=save" method="POST">
                         <input type="hidden" name="original_filename" value="<?php echo htmlspecialchars($original_filename_for_form); ?>">

                         <div class="form-group">
                             <label for="doc_name">اسم المستند:</label>
                             <input type="text" id="doc_name" name="doc_name" value="<?php echo htmlspecialchars($doc_name); ?>" required placeholder="اسم المستند (يفضل بدون رموز خاصة)" maxlength="60" <?php if ($action === 'new') echo 'autofocus'; ?>>
                             <small>يمكن استخدام الحروف والأرقام والشرطة (-) والشرطة السفلية (_). سيتم تحويل المسافات والرموز الأخرى إلى شرطة سفلية. تغيير الاسم هنا سيؤدي إلى إعادة تسمية الملف.</small>
                         </div>

                         <div class="form-group">
                             <label for="editorArea">المحتوى:</label>
                             <textarea id="editorArea" name="content" style="width: 100%;"><?php echo htmlspecialchars($doc_content); ?></textarea>
                         </div>

                         <button type="submit" class="button">حفظ المستند</button>
                         <a href="index.php?action=list" class="button button-cancel" style="margin-right: 10px;">إلغاء</a>
                    </form>
                <?php
                elseif ($action === 'list'):
                     echo "<h2>لوحة التحكم</h2>";
                     echo "<p>مرحباً بك في محرر المستندات البسيط. اختر مستندًا من القائمة على اليمين للتحرير، أو انقر فوق 'إنشاء مستند جديد'.</p>";
                     echo "<p>يمكنك نشر مستند للحصول على رابط مؤقت (لمدة " . PUBLISH_LIFETIME_DAYS . " يومًا) لمشاركته للقراءة فقط.</p>";
                     echo "<p style='margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee;'>عدد المستندات الحالية: <strong>" . count($files) . " / " . MAX_FILES_PER_USER . "</strong></p>";
                else:
                     echo "<h2>خطأ</h2><div class='message error'>الإجراء المطلوب غير معروف أو حدث خطأ.</div>";
                endif;
                ?>
            </main>
        </div>

    <?php endif; ?>

</body>
</html>